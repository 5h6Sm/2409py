# 2409 임수민

def intersect(l1, l2):
    li =[]
    value = [] 

    for i in l1:
        for j in l2:
            if i == j:
                li += i
    value = list(set(li))
    value.sort()

    return value

firstS = input('첫 번째 문자열 입력 : ')
secondS = input('두 번째 문자열 입력 : ')

s1 = list(firstS)
s2 = list(secondS)

print(intersect(s1, s2))