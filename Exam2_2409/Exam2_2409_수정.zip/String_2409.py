#2409 임수민

str = input("문자열 입력 : ")
n = len(str)
s = '반짝~'

print(s * n)