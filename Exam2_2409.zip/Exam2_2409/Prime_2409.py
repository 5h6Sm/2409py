#2409 임수민

def isPrimeNumber(num):
    count=0

    print("소수 : ",end="")
    for i in range(1, num+1, 1):
        value=1
        for j in range(2, i, 1):
            if i % j == 0:
                value = 0 
                break  
        if value == 0:
            continue
        else:
            print(i," ", end="")
            count = count+1
    print()
    print("1 ~ ",num,"까지 소수의 갯수 : ",count-1)



print("1 ~ N 까지의 소수와 그 갯수를 구하는 프로그램")
num = int(input("N 입력 : "))

isPrimeNumber(num)

