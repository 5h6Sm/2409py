#2409 임수민

str = input("영문자 입력 : ")
num = len(str)
trs = list(str)
trs.reverse()
print("거꾸로 출력 : ",end="")
for i in trs:
    print(i,end="")