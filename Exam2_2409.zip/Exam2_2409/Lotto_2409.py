#2409 임수민

import random

def func_lotto():

    rand = ()

    for i in range(6):
        n = random.randint(1, 45)
        rand+=(n,)

    r = list(rand)
    r.sort()
   
    print("당첨번호 : ", end="")

    for i in range(6):
        print(r[i],"", end="")
    print()

    
for i in range(1, 11, 1):
    func_lotto()